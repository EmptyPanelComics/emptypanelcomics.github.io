+ + + + - Empty

im not doing so well

it does feel like you all hate me sometimes

i dont fit in inside your small little boxes, and now im being torn apart so i can fit in them

if you want to support me, feel free to donate to my kofi:
https://ko-fi.com/jjjnco