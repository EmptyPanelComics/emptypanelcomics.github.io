╣ - Empty

Hello, it is me, Empty. Thank you for downloading this free EP.

im not doing too well, but i've been trying to see things in a slightly better light.
of course, its nigh impossible with all the nonsense happening all the time, but i hope that im able to cope with all of this.

i hope you enjoy ╣.

this album is free, and should be shared to everyone.
if you want to support me, feel free to donate to my kofi:
https://ko-fi.com/jjjnco