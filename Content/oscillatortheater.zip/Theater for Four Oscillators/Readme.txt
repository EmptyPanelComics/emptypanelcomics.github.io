Theater for Four Oscillators - Empty

Hello, it is me, Empty. Thank you for downloading this free EP. I wanted to try something new today.

This EP is performed by 4 Oscillators and 5 LFOs. It is a journey of realization and acceptance. it is Theater made by, and for Oscillators.

this album is free, and should be shared to everyone.
if you want to support me, feel free to donate to my kofi:
https://ko-fi.com/jjjnco